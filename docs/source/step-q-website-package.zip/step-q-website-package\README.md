# STEP-Q: Website-Abschnitte

Dieses Paket enthaelt die abgestimmten Abschnitte **Wie es funktioniert** und **Entgraten** zur Integration in eine bestehende Website. Es benoetigt weder JavaScript noch externe Bibliotheken, Webfonts oder einen Build-Schritt.

## Einstieg

1. Den gesamten Paketordner in das Hauptprojekt legen.
2. Copilot die Datei [COPILOT-INTEGRATION.md](COPILOT-INTEGRATION.md) als Kontext geben und um Ausfuehrung bitten.
3. Die Datei [index.html](index.html) direkt im Browser oeffnen, um beide Abschnitte als visuelle Referenz zu sehen. Diese Vorschauseite nicht als neue Hauptseite importieren.

## Inhalt

```text
step-q-website-package/
  README.md
  COPILOT-INTEGRATION.md
  index.html                         Gemeinsame Vorschau
  sections/
    wie-es-funktioniert.html         HTML-Fragment ohne Seitenhuelle
    entgraten.html                   HTML-Fragment ohne Seitenhuelle
  styles/
    wie-es-funktioniert.css          CSS nur fuer .step-q-process
    entgraten.css                    CSS nur fuer .deburr
  assets/images/
    daten-erkennen.png
    pruefen.png
    mitgeben.png
    weiterverarbeiten.png
    entgraten-bauteil.png
    entgraten-vorher.png
    entgraten-nachher.png
    entgraten-symbol.png
```

Die Bilddateien wurden unveraendert kopiert; nur die vier Prozessbilder haben einheitliche ASCII-Dateinamen erhalten. Die grossen Gesamtvorlagen sind fuer die Integration nicht erforderlich und daher nicht enthalten.

## Technische Hinweise

- Die Fragmente enthalten echte Texte, semantische Listen, eine Tabelle, Alternativtexte und ARIA-Beschriftungen.
- Die Bildpfade `assets/images/...` beziehen sich auf die einbettende Seite, nicht auf den Speicherort des Fragments. Im Hauptprojekt muessen sie an dessen Asset-Konvention angepasst werden.
- Beide Stylesheets verwenden benannte CSS-Container-Queries. Das Layout reagiert auf die Breite des jeweiligen Abschnitts, nicht nur auf die Fensterbreite. Erforderlich sind aktuelle Browser mit Container-Query-Unterstuetzung, etwa Chrome/Edge 105+, Firefox 110+ oder Safari 16+.
- Klassen und CSS-Variablen haben eigene Namensraeume. Globale CSS-Regeln der Hauptwebsite koennen dennoch eingreifen; die Integration muss in der echten Seite geprueft werden.
- Vorschau-Regeln fuer `body` wurden aus den gelieferten Stylesheets entfernt. Die Originalvorschauen im kleinen Projekt wurden nicht veraendert.
- Die Hauptueberschrift von Entgraten ist im Fragment ein `h2` mit Klasse `deburr__heading` statt des `h1` der Einzelvorschau. Ihre Darstellung bleibt gleich. Die uebrige Ueberschriftenhierarchie muss zur Zielseite passen.
- Die Entgraten-Fotos und das Symbol sind Ausschnitte der gelieferten Gesamtvorlage, keine neu gerenderten hochaufloesenden Originalbilder. Insbesondere die Vorher-/Nachher-Fotos nicht unnoetig vergroessern.
- Das Bauteilfoto enthaelt bereits eine Kantenmarkierung und eine eingebrannte Beschriftung. Eine HTML-Beschriftung ueberlagert diese. Position, Bildausschnitt und Hintergrund dieses Bereichs zusammen erhalten; fuer eine andere Bildposition waere ein unbeschriftetes Original vorzuziehen.

## Freigegebene Details

- Kein Strich unter der oberen Beschriftung "Wie es funktioniert".
- Bildskalierungen in Prozessreihenfolge: **1.18 / 1.27 / 1.10 / 1.12**. "Daten erkennen" wurde zuletzt bewusst vergroessert.
- "Rueckseitig": nur Rueckseite entgratet. "Zweiseitig": Vorder- und Rueckseite entgratet.
- Gratfrei bedeutet nicht automatisch abgerundet oder frei von scharfen Kanten. Der Hinweis auf moegliche Oberflaechenveraenderung bleibt erhalten.

Die Einzelabschnitte wurden im Quellprojekt bei mobilen, mittleren und grossen Breiten getestet. Diese Pruefung ersetzt nicht die Validierung im CSS- und Layout-Kontext der Hauptwebsite.